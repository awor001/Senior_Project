The following instructions outline how to configure an expert using the following signals:

Moving Average - (Provided by MQL5)
SJY - (Created by Jonathan Jimenez)
Head and Shoulders - (Created by Justin Keefe)
Double Top and Bottom - (Created by Christopher Fernandez)

The following weights should be used as follows:
Moving Average - 0.6
SJY - 0.8
Head and Shoulders - 0.5
Double Top and Bottom - 0.4

Using the wizard, you can adjust these weights as you add each signal. For the moving average, the parameters are kept at their default values. Once the wizard generates the expert advisor, the next step is to compile the code and once it compiles successfully, open it in strategy tester within MetaTrader 5.

Instructions: 

Compile Expert Advisor BigDaddyRubberBandExpert.mq5
Wait until it compiles
Run a test on chart type H4 (chart advisor is made for)
Test on charts of type H4