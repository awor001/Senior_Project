Read Me Head and Shoulders Signal

This trading signal works on the head and shoulders pattern. It detects two outer smaller peaks and a larger inner peak and then a signal for a sell will occur. 
Or the signal detects two smaller outer troughs and a larger inner trough for a reverse head and shoulders pattern. The five main functions you should be concerned with
are CheckSignal() found in HS_Pattern, CheckPatternBuy, CheckPatternSell, Long Condition, and Short Condition all foundin the Signal. 
CheckSignal() detects whether it is worthy to open a buy or sell order and also sets possible take profit and stop loss for pattern checking later.
CheckPatternBuy() evaluates if the check signal is 1 and a reverse head and shoulders is located this function will return false if an order for buy should be opened.
CheckPatternSell() evaluates if the check signal is -1 and a head and shoulders is located this function will return false if an order for sell should be opened.
LongCondition() evaluates whether a pattern is worthy to open a sale for buying for reverse head and shoulders.
ShortCondition() evaluates whether a pattern is worthy to open a sale for selling for head and shoulders.

Video:
https://youtu.be/sLh0Fwd10CY

Parameters: 
ZigZag:
Depth = 12
Deviation = 100
Backstep = 3
Max history, bars = 1000
Work Timeframe = 30 minutes

Pattern:
Minimal Correction = 0.06
Maximal Correction = 0.48 
Timeframe for confirmation = 5 minutes

Weight Suggestion:
I suggest a weight between 0.4 - 0.6
The reason being that this signal is very specific and only occurs a few times a year (usually 20 - 40) so if you base to many trades off it you may reject alot of your trades.
A smaller weight should not interfere with other trades while still giving an input. 

