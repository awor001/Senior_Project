RandomForestSignal_VictorBouza.mqh 
-------------------------------------------------------------
* This is a signal that uses the random forest algorithm with multiple agents. This way, we can maximize the probability of randomly getting
the best possible model to be used in the market. To use the algorithm, please refer to the sample Expert Advisor located at 
MQL5\Experts\RandomForestExpert_VictorBouza.mq5. 

* Pleas make sure you add a pointer instance of the RFAgentCollection.mqh in your expert and send it to the random forest singal as a parameter in the constructor. 
For more information, please refer to the random forest algorithm video (https://www.youtube.com/watch?v=_WLjelBFyq0) and the files located at
MQL5\Include\RandomForest

* If you experience any issue with the expert advisor parameter name generator, please use simpler names like the ones present in the file RandomForestExpert_VictorBouza.mq5. 

* Parameter value recommendations:
number_of_passes = 50
shift_probab = 0.01
regularize = 0.2
number_of_best_features = 15
treshhold 0.1
MaximumRisk 0.01
CustomLot 0
Signal_RF_Weight 0.6

* This signal is capable of learning. It learns by calling the method agentCollection.learnAll(). The output of the learning process can be located outside the MQL5 directory,
at Tester\cache. If something goes wrong with the learning process you can simply clear the cache folder and start again.



* The random forest algorithm video also contains a tutorial on how to train the signal in the optimizer. 
Brief summary of the tutorial:
To make the algorithm learn, please right click the expert advisor and click Test. Then select Find optimal parameters of an Expert Advisor using complete serach (slow). Select your Symbol and M15. Select the date range (have in mind that a good date range of about 3-4 years might take days to finish and it will use 100% of the computer's CPU). Select Open Prices Only and Optimization Custom max. Go to the Inputs tab and modify the following parameters (recommended):
Variable		Value	Start	Step	Stop
number_of_passes	50	0	1	30
shift_probab		0.01	0.1	0.1	0.3
regularize		0.2	0.1	0.1	0.4	
treshold		0.1	

Then go back to the Settings tab and click on Start. Do not interrupt the learning process; wait until the end and if possible restart MetaTrader5.