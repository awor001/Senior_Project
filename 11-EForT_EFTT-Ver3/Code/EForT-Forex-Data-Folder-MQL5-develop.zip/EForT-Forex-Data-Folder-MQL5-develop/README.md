# EForT-Forex-Data-Folder-MQL5
## Steps for Cloning Repository for First Time
1. Download MetaTrader5
2. Find Data Folder
* File -> Open Data Folder (You'll probably want to pin this)
* Close MT5 after finding the data folder
3. Remove everything in the data folder and store it somewhere else.
4. Open a terminal at the data folder and enter the following: `git clone url .`
5. Copy back files of directory that you stored
* You can skip all files that it asks to overwrite
6. Run MT5 and after a few seconds you should be good to go!
